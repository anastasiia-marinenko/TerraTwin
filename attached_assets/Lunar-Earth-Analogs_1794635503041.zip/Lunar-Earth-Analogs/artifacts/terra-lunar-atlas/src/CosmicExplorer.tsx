import { useEffect, useMemo, useRef, useState } from 'react';
import { Map as MapLibre, setWorkerUrl, type Map as MapLibreMap, Marker } from 'maplibre-gl';
import mapWorkerUrl from 'maplibre-gl/dist/maplibre-gl-worker.mjs?worker&url';
import 'maplibre-gl/dist/maplibre-gl.css';
import * as L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import './cosmic-explorer.css';
import {
  Activity, Check, CircleHelp, Compass, Crosshair, Filter, Globe2,
  Map as MapIcon, Orbit, RotateCcw, Search, Share2, SlidersHorizontal, Star, Target, ExternalLink,
} from 'lucide-react';
import {
  caseStudies, earthSites, knownAnalogIds, targets,
  type EarthSite, type FeatureGroup, type FeatureWeights, type SimilarityMetric, type TargetSite,
} from '@/data/analogs';
import { getRankedMatches, isNewCandidate, type RankedMatch, type RankingResult } from '@/lib/science';
import FieldPhotographs from '@/components/FieldPhotographs';

setWorkerUrl(mapWorkerUrl);

type ViewMode = 'globe' | 'flat';
const satelliteTiles = 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}';
const satelliteAttribution = 'Imagery tiles © Esri; sources include Maxar, Earthstar Geographics, and the GIS User Community.';
const groups: FeatureGroup[] = ['slopes', 'roughness', 'relief', 'curvature'];
const labels: Record<FeatureGroup, string> = {
  slopes: 'Slope distribution',
  roughness: 'Surface roughness',
  relief: 'Elevation relief',
  curvature: 'Terrain shape',
};
const metrics: Record<SimilarityMetric, string> = {
  ensemble: 'Ensemble',
  cosine: 'Cosine similarity',
  mahalanobis: 'Mahalanobis distance',
  wasserstein: 'Wasserstein distance',
};
const metricNotes: Record<SimilarityMetric, string> = {
  ensemble: 'Mean of cosine, diagonal Mahalanobis, and Wasserstein comparisons.',
  cosine: 'Cosine similarity is compared within each feature group.',
  mahalanobis: 'Robust diagonal approximation; full covariance is not estimated.',
  wasserstein: 'Compares slope histograms and feature distributions.',
};
const scale: Record<FeatureGroup, number> = { slopes: 35, roughness: 140, relief: 1400, curvature: 1 };
const slopeCenters = [1, 3.5, 7.5, 12.5, 17.5, 22.5, 27.5, 35];
const defaultWeights: FeatureWeights = { slopes: 1, roughness: 1, relief: 1, curvature: 1 };

function format(value: number, places = 1) {
  return new Intl.NumberFormat('en-US', { maximumFractionDigits: places }).format(value);
}

function coords(site: EarthSite | TargetSite) {
  const lat = `${Math.abs(site.latitude).toFixed(2)}°${site.latitude < 0 ? 'S' : 'N'}`;
  const lon = `${Math.abs(site.longitude).toFixed(2)}°${site.longitude < 0 ? 'W' : 'E'}`;
  return `${lat}, ${lon}`;
}

function profileValues(site: EarthSite | TargetSite): Record<FeatureGroup, number> {
  const total = site.profile.slopeHistogram.reduce((sum, value) => sum + value, 0);
  return {
    slopes: total ? site.profile.slopeHistogram.reduce((sum, value, i) => sum + value * (slopeCenters[i] ?? 35), 0) / total : 0,
    roughness: (site.profile.roughness1Km + site.profile.roughness5Km) / 2,
    relief: site.profile.reliefP99P1,
    curvature: (site.profile.concavity + site.profile.convexity) / 2,
  };
}

function units(group: FeatureGroup) {
  return group === 'slopes' ? '°' : group === 'curvature' ? '' : ' m';
}

function supportsWebGL2() {
  try {
    const canvas = document.createElement('canvas');
    const context = canvas.getContext('webgl2', { failIfMajorPerformanceCaveat: false });
    const supported = Boolean(context);
    context?.getExtension('WEBGL_lose_context')?.loseContext();
    return supported;
  } catch {
    return false;
  }
}

function readUrlState() {
  const params = new URLSearchParams(window.location.search);
  const targetId = targets.find((item) => item.id === params.get('target'))?.id ?? targets[0].id;
  const allowedMetrics: SimilarityMetric[] = ['ensemble', 'cosine', 'mahalanobis', 'wasserstein'];
  const metric = allowedMetrics.includes(params.get('metric') as SimilarityMetric) ? params.get('metric') as SimilarityMetric : 'ensemble';
  const view: ViewMode = params.get('view') === 'flat' ? 'flat' : 'globe';
  const satellite = params.get('imagery') === 'satellite';
  const siteId = earthSites.find((item) => item.id === params.get('site'))?.id ?? '';
  const parseWeight = (key: FeatureGroup) => {
    const raw = params.get(`w-${key}`);
    if (raw === null || raw.trim() === '') return 1;
    const value = Number(raw);
    return Number.isFinite(value) ? Math.max(0, Math.min(5, value)) : 1;
  };
  const weights: FeatureWeights = {
    slopes: parseWeight('slopes'),
    roughness: parseWeight('roughness'),
    relief: parseWeight('relief'),
    curvature: parseWeight('curvature'),
  };
  const rawDistance = params.get('novelty-km');
  const distance = rawDistance === null || rawDistance.trim() === ''
    ? 200
    : Number(rawDistance);
  return {
    targetId, metric, view, siteId, weights, satellite,
    onlyNew: params.get('novel') === '1',
    minDistanceKm: Number.isFinite(distance) ? Math.max(0, Math.min(1000, distance)) : 200,
  };
}

function ProfileComparison({ target, site }: { target: TargetSite; site?: EarthSite }) {
  const targetValues = profileValues(target);
  const siteValues = site ? profileValues(site) : undefined;
  return (
    <section className="tt-detail" aria-live="polite">
      <div className="tt-detail-top">
        <div>
          <div className="tt-kicker">Selected field analogue</div>
          <h2>{site?.name ?? 'Select a field site'}</h2>
          <p className="tt-detail-region">{site ? `${site.region} · ${site.country}` : 'Choose a ranked candidate to inspect its profile.'}</p>
        </div>
        {site && <span className="tt-mono tt-coordinates">{coords(site)}</span>}
      </div>
      {site && <>
        <p className="tt-summary">{site.terrain}.</p>
        <a className="tt-street-view" href={`https://www.google.com/maps/@?api=1&map_action=pano&viewpoint=${site.latitude},${site.longitude}`} target="_blank" rel="noreferrer" data-testid="link-google-maps-360">
          <ExternalLink size={13} /> Open Google Maps 360° at these coordinates
        </a>
        <p className="tt-street-view-note">Street View coverage may not exist at this remote field site; Google Maps will open at the selected coordinates.</p>
      <div className="tt-data-label"><Activity size={12} /> Illustrative demo values · not raster-derived measurements</div>
        <div className="tt-profile-grid" aria-label="Illustrative feature comparison">
          {groups.map((group) => {
            const siteValue = siteValues![group];
            const targetValue = targetValues[group];
            const siteWidth = Math.max(3, Math.min(100, siteValue / scale[group] * 100));
            const targetWidth = Math.max(3, Math.min(100, targetValue / scale[group] * 100));
            return <div className="tt-profile-row" key={group}>
              <div className="tt-profile-head"><span>{labels[group]}</span><b>{format(siteValue)}{units(group)}</b></div>
              <div className="tt-profile-bar"><span style={{ width: `${siteWidth}%` }} /></div>
              <div className="tt-profile-head tt-profile-target"><span>{target.name} reference</span><span>{format(targetValue)}{units(group)}</span></div>
              <div className="tt-profile-bar"><span className="tt-target-bar" style={{ width: `${targetWidth}%` }} /></div>
            </div>;
          })}
        </div>
        <div className="tt-detail-notes">
          <p><strong>Rehearsal use:</strong> {site.missionUse}</p>
          <p><strong>Analogy limit:</strong> {site.breaksDown}</p>
        </div>
        <FieldPhotographs site={site} />
      </>}
    </section>
  );
}

function MatchExplanation({
  match,
  target,
  metric,
  minDistanceKm,
}: {
  match?: RankedMatch;
  target: TargetSite;
  metric: SimilarityMetric;
  minDistanceKm: number;
}) {
  if (!match) return null;
  const isNovel = isNewCandidate(match.site, knownAnalogIds, minDistanceKm);
  return (
    <section className="tt-explanation" aria-live="polite">
      <div className="tt-explanation-head">
        <div><div className="tt-kicker">Model interpretation</div><h2>Why this site ranks here</h2></div>
        <div className="tt-explanation-score"><strong>{format(match.score)}</strong><span>/ 100 · {metrics[metric]}</span></div>
      </div>
      <div className="tt-explanation-grid">
        <div>
          <h3>Strongest feature signals</h3>
          {match.reasons.length
            ? <ul>{match.reasons.map((reason) => <li key={reason}>{reason}</li>)}</ul>
            : <p>No feature signal is available for this comparison.</p>}
        </div>
        <div>
          <h3>Largest mismatches</h3>
          {match.differences.length
            ? <ul>{match.differences.map((difference) => <li key={difference}>{difference}</li>)}</ul>
            : <p>No dominant mismatch is flagged in this comparison.</p>}
        </div>
      </div>
      <div className="tt-explanation-foot">
       <span>{target.name} → {match.site.name}</span>
       <span>Candidate-set percentile {format(match.percentile, 0)} · {isNovel ? 'Passes the distance screen' : 'Known-site proximity rule not met'} · {format(match.noveltyDistanceKm, 0)} km from nearest reference</span>
      </div>
      <p className="tt-explanation-caveat">Interpretation comes from illustrative demo profiles and the selected local metric; it is not a raster-derived scientific finding.</p>
    </section>
  );
}

export default function CosmicExplorer() {
  const initial = useMemo(readUrlState, []);
  const [targetId, setTargetId] = useState(initial.targetId);
  const globeSupported = useMemo(supportsWebGL2, []);
  const [metric, setMetric] = useState<SimilarityMetric>(initial.metric);
  const [viewMode, setViewMode] = useState<ViewMode>(globeSupported ? initial.view : 'flat');
  const [satelliteMode, setSatelliteMode] = useState<boolean>(initial.satellite);
  const [weights, setWeights] = useState<FeatureWeights>(initial.weights);
  const [onlyNew, setOnlyNew] = useState(initial.onlyNew);
  const [minDistanceKm, setMinDistanceKm] = useState(initial.minDistanceKm);
  const [query, setQuery] = useState('');
  const [selectedId, setSelectedId] = useState(initial.siteId);
  const [mapKey, setMapKey] = useState(0);
  const [map, setMap] = useState<MapLibreMap | null>(null);
  const [leafletMap, setLeafletMap] = useState<L.Map | null>(null);
  const [mapRenderer, setMapRenderer] = useState<'maplibre' | 'leaflet'>('maplibre');
  const [mapLoaded, setMapLoaded] = useState(false);
  const [mapError, setMapError] = useState('');
  const [shortlist, setShortlist] = useState<string[]>(() => {
    try {
      const saved: unknown = JSON.parse(localStorage.getItem('terratwin-field-shortlist') ?? '[]');
      return Array.isArray(saved) ? saved.filter((id): id is string => typeof id === 'string' && earthSites.some((site) => site.id === id)) : [];
    } catch {
      return [];
    }
  });
  const [shareStatus, setShareStatus] = useState('');
  const mapHost = useRef<HTMLDivElement>(null);
  const markers = useRef<Marker[]>([]);
  const rasterMarkers = useRef<L.Marker[]>([]);
  const satelliteLeafletLayer = useRef<L.TileLayer | null>(null);
  const markerButtons = useRef(new Map<string, HTMLButtonElement>());
  const target = targets.find((item) => item.id === targetId) ?? targets[0];
  const canUseGlobe = globeSupported && mapRenderer === 'maplibre';

  const ranking = useMemo((): { result: RankingResult | null; error: string } => {
    if (groups.every((group) => weights[group] <= 0)) return { result: null, error: 'Set a positive weight for at least one feature group.' };
    try {
      return { result: getRankedMatches(targetId, metric, weights, 20, 200), error: '' };
    } catch (error) {
      return { result: null, error: error instanceof Error ? error.message : 'The local ranking calculation failed.' };
    }
  }, [targetId, metric, weights]);
  const rows = ranking.result?.results ?? [];
  const eligibleIds = useMemo(
    () => new Set(earthSites.filter((site) => isNewCandidate(site, knownAnalogIds, minDistanceKm)).map((site) => site.id)),
    [minDistanceKm],
  );
  const matches = useMemo(() => rows.filter((row) =>
    (!onlyNew || eligibleIds.has(row.site.id))
    && `${row.site.name} ${row.site.region} ${row.site.country}`.toLowerCase().includes(query.toLowerCase()),
  ), [rows, onlyNew, eligibleIds, query]);
  const activeMatch = matches.find((row) => row.site.id === selectedId) ?? matches[0];
  const activeSite = activeMatch?.site;

  useEffect(() => {
    const next = activeMatch?.site.id ?? '';
    if (next !== selectedId) setSelectedId(next);
  }, [activeMatch?.site.id, selectedId]);

  useEffect(() => {
    const host = mapHost.current;
    if (!host) return;
    setMap(null);
    setLeafletMap(null);
    setMapLoaded(false);
    setMapError('');
    let styleLoaded = false;
    let instance: MapLibreMap | null = null;
    let fallback: L.Map | null = null;
    const useRasterFallback = () => {
      fallback = L.map(host, { zoomControl: false, attributionControl: false, worldCopyJump: true }).setView([18, 15], 2);
      L.control.zoom({ position: 'bottomleft' }).addTo(fallback);
      L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '© OpenStreetMap contributors',
        crossOrigin: true,
      }).addTo(fallback);
      satelliteLeafletLayer.current = L.tileLayer(satelliteTiles, {
        maxZoom: 19,
        attribution: satelliteAttribution,
        crossOrigin: true,
      });
      if (satelliteMode) satelliteLeafletLayer.current.addTo(fallback);
      setMapRenderer('leaflet');
      setLeafletMap(fallback);
      setMapLoaded(true);
      setViewMode('flat');
    };
    if (globeSupported) {
      try {
        instance = new MapLibre({
          container: host,
          style: 'https://tiles.openfreemap.org/styles/dark',
          center: [15, 18],
          zoom: 1.45,
          minZoom: 1,
          maxZoom: 12,
          attributionControl: false,
          cooperativeGestures: true,
        });
        setMapRenderer('maplibre');
        setMap(instance);
        instance.on('load', () => {
          styleLoaded = true;
          instance?.addSource('satellite-imagery', {
            type: 'raster',
            tiles: [satelliteTiles],
            tileSize: 256,
            attribution: satelliteAttribution,
            maxzoom: 19,
          });
          instance?.addLayer({
            id: 'satellite-imagery-layer',
            type: 'raster',
            source: 'satellite-imagery',
            layout: { visibility: satelliteMode ? 'visible' : 'none' },
            paint: { 'raster-opacity': 1 },
          });
          setMapLoaded(true);
          instance?.setProjection({ type: viewMode === 'globe' ? 'globe' : 'mercator' });
        });
        instance.on('error', (event) => {
          if (!styleLoaded) setMapError(event.error?.message || 'The vector map could not be loaded. Check the connection and retry.');
        });
      } catch {
        useRasterFallback();
      }
    } else {
      useRasterFallback();
    }
    const observer = new ResizeObserver(() => {
      instance?.resize();
      fallback?.invalidateSize();
    });
    observer.observe(host);
    return () => {
      observer.disconnect();
      markers.current.forEach((marker) => marker.remove());
      markers.current = [];
      rasterMarkers.current.forEach((marker) => marker.remove());
      rasterMarkers.current = [];
      satelliteLeafletLayer.current = null;
      instance?.remove();
      fallback?.remove();
      setMap((current) => current === instance ? null : current);
      setLeafletMap((current) => current === fallback ? null : current);
    };
  }, [mapKey, globeSupported]);

  useEffect(() => {
    if (map && mapLoaded) map.setProjection({ type: viewMode === 'globe' ? 'globe' : 'mercator' });
  }, [map, mapLoaded, viewMode]);

  useEffect(() => {
    if (map && mapLoaded && map.getLayer('satellite-imagery-layer')) {
      map.setLayoutProperty('satellite-imagery-layer', 'visibility', satelliteMode ? 'visible' : 'none');
    }
    if (leafletMap && satelliteLeafletLayer.current) {
      if (satelliteMode && !leafletMap.hasLayer(satelliteLeafletLayer.current)) satelliteLeafletLayer.current.addTo(leafletMap);
      if (!satelliteMode && leafletMap.hasLayer(satelliteLeafletLayer.current)) leafletMap.removeLayer(satelliteLeafletLayer.current);
    }
  }, [map, leafletMap, mapLoaded, satelliteMode]);

  useEffect(() => {
    if ((!map && !leafletMap) || !mapLoaded) return;
    markers.current.forEach((marker) => marker.remove());
    markers.current = [];
    rasterMarkers.current.forEach((marker) => marker.remove());
    rasterMarkers.current = [];
    markerButtons.current.clear();
    matches.forEach((row, index) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = `tt-map-marker${row.site.id === activeSite?.id ? ' is-selected' : ''}`;
      button.setAttribute('aria-label', `Select ${row.site.name}, ranked ${index + 1}`);
      button.setAttribute('aria-pressed', String(row.site.id === activeSite?.id));
      button.setAttribute('data-testid', `map-marker-${row.site.id}`);
      button.title = `${index + 1}. ${row.site.name} · ${format(row.score)} similarity`;
      button.innerHTML = '<span aria-hidden="true"></span>';
      button.addEventListener('click', (event) => {
        event.stopPropagation();
        setSelectedId(row.site.id);
        if (map) map.flyTo({ center: [row.site.longitude, row.site.latitude], zoom: Math.max(map.getZoom(), 2.25), duration: 650 });
        else leafletMap?.flyTo([row.site.latitude, row.site.longitude], Math.max(leafletMap.getZoom(), 5), { duration: 0.65 });
      });
      if (map) {
        markers.current.push(new Marker({ element: button, anchor: 'center' }).setLngLat([row.site.longitude, row.site.latitude]).addTo(map));
        markerButtons.current.set(row.site.id, button);
      } else if (leafletMap) {
        const iconButton = button.cloneNode(true) as HTMLButtonElement;
        iconButton.addEventListener('click', (event) => {
          event.stopPropagation();
          setSelectedId(row.site.id);
          leafletMap.flyTo([row.site.latitude, row.site.longitude], Math.max(leafletMap.getZoom(), 5), { duration: 0.65 });
        });
        const icon = L.divIcon({ className: 'tt-leaflet-marker-shell', html: iconButton, iconSize: [24, 24], iconAnchor: [12, 12] });
        rasterMarkers.current.push(L.marker([row.site.latitude, row.site.longitude], { icon, keyboard: true, title: button.title, alt: button.getAttribute('aria-label') ?? '' }).addTo(leafletMap));
      }
    });
    markerButtons.current.get(activeSite?.id ?? '')?.classList.add('is-selected');
  }, [map, leafletMap, mapLoaded, matches, activeSite?.id]);

  useEffect(() => {
    try { localStorage.setItem('terratwin-field-shortlist', JSON.stringify(shortlist)); } catch { /* Storage can be unavailable in private browsing. */ }
    window.dispatchEvent(new Event('terratwin-shortlist-change'));
  }, [shortlist]);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    params.set('target', targetId);
    if (activeSite) params.set('site', activeSite.id);
    else params.delete('site');
    params.set('metric', metric);
    params.set('view', viewMode);
    params.set('imagery', satelliteMode ? 'satellite' : 'geographic');
    params.set('novel', onlyNew ? '1' : '0');
    params.set('novelty-km', String(minDistanceKm));
    groups.forEach((group) => params.set(`w-${group}`, String(weights[group])));
    const search = params.toString();
    window.history.replaceState({}, '', `${window.location.pathname}${search ? `?${search}` : ''}${window.location.hash}`);
  }, [targetId, activeSite?.id, metric, viewMode, weights, onlyNew, minDistanceKm, satelliteMode]);

  function toggleShortlist(id: string) {
    setShortlist((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
  }

  async function share() {
    setShareStatus('');
    try {
      await navigator.clipboard.writeText(window.location.href);
      setShareStatus('Link copied');
    } catch {
      const input = document.createElement('textarea');
      input.value = window.location.href;
      input.style.position = 'fixed';
      input.style.opacity = '0';
      document.body.append(input);
      input.select();
      const copied = document.execCommand('copy');
      input.remove();
      setShareStatus(copied ? 'Link copied' : 'Copy unavailable');
    }
    window.setTimeout(() => setShareStatus(''), 2400);
  }

  function openCase(study: (typeof caseStudies)[number]) {
    setTargetId(study.targetId);
    setOnlyNew(false);
    setQuery('');
    setSelectedId(study.siteId);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  return <div className="tt-cosmic">
    <div className="tt-shell">
      <header className="tt-topbar">
        <a className="tt-brand" href="#mission" aria-label="TerraTwin expedition instrument" data-testid="link-explorer-mission">
          <span className="tt-brand-mark"><Orbit size={19} /></span>
          <span><span className="tt-brand-name">TerraTwin</span><span className="tt-brand-sub">Earth analog explorer</span></span>
        </a>
        <div className="tt-status"><span className="tt-status-dot" /> Illustrative profile comparison</div>
        <button type="button" className="tt-share" data-testid="button-share-comparison" onClick={share} aria-label="Copy a shareable comparison link">
          {shareStatus ? <Check size={14} /> : <Share2 size={14} />}{shareStatus || 'Share comparison'}
        </button>
      </header>

      <main id="mission">
        <section className="tt-intro">
          <div>
            <div className="tt-eyebrow">Earth analog selection · mission planning</div>
            <h1 className="tt-title">Rehearse the terrain.<br /><em>Interrogate the match.</em></h1>
            <p className="tt-intro-copy">Explore real Earth geography, compare field sites with a lunar or Martian target, and test how your assumptions change the shortlist.</p>
          </div>
          <aside className="tt-brief">
            <div className="tt-brief-label">Mission question</div>
            <p>Which Earth site can help rehearse this terrain operation?</p>
          </aside>
        </section>

        <section className="tt-controls" aria-label="Comparison controls" data-tour="feature-controls">
          <div>
            <label className="tt-field-label" htmlFor="tt-target"><Target size={13} /> Target terrain</label>
            <select id="tt-target" className="tt-select" data-testid="select-target" value={targetId} onChange={(event) => { setTargetId(event.target.value); setSelectedId(''); }}>
              {targets.map((item) => <option key={item.id} value={item.id}>{item.name} · {item.body === 'moon' ? 'Moon' : 'Mars'} · {item.region}</option>)}
            </select>
          </div>
          <div>
            <label className="tt-field-label" htmlFor="tt-metric"><Activity size={13} /> Similarity metric</label>
            <select id="tt-metric" className="tt-select" data-testid="select-metric" value={metric} onChange={(event) => setMetric(event.target.value as SimilarityMetric)}>
              {(Object.keys(metrics) as SimilarityMetric[]).map((key) => <option key={key} value={key}>{metrics[key]}</option>)}
            </select>
          </div>
          <label className="tt-check">
            <input type="checkbox" data-testid="toggle-new-candidates" checked={onlyNew} onChange={(event) => setOnlyNew(event.target.checked)} />
            <span><Filter size={13} />Only distance-screened candidates</span>
          </label>
          <button type="button" className="tt-reset" data-testid="button-reset" onClick={() => { setMetric('ensemble'); setWeights(defaultWeights); setMinDistanceKm(200); setOnlyNew(false); setQuery(''); setSelectedId(''); }}>
            <RotateCcw size={13} /> Reset
          </button>
        </section>

        <section className="tt-workspace">
          <div className="tt-map-column" data-tour="explorer-map">
            <div className="tt-map-head">
              <div><div className="tt-kicker">Earth · global reference map</div><h2>Explore candidate terrain</h2></div>
              <div className="tt-map-actions" role="group" aria-label="Map display">
              <button type="button" className="tt-view-button" data-testid="toggle-globe-view" aria-pressed={viewMode === 'globe' && canUseGlobe} disabled={!canUseGlobe} title={canUseGlobe ? 'Switch to globe projection' : 'Globe projection requires WebGL2 and the vector map'} onClick={() => setViewMode('globe')}><Globe2 size={13} />Globe</button>
                <button type="button" className="tt-view-button" data-testid="toggle-flat-view" aria-pressed={viewMode === 'flat'} onClick={() => setViewMode('flat')}><MapIcon size={13} />Flat map</button>
                <button type="button" className="tt-view-button" data-testid="toggle-satellite-imagery" aria-pressed={satelliteMode} onClick={() => setSatelliteMode((current) => !current)}>Satellite</button>
              </div>
            </div>
            <div className="tt-map-frame">
              <div ref={mapHost} className="tt-map" data-testid="map-canvas" role="application" aria-label="Interactive Earth map showing ranked field-site locations" />
              <div className="tt-map-badge">{satelliteMode ? 'Satellite imagery · visual context' : mapRenderer === 'leaflet' ? 'OpenStreetMap · geographic context' : viewMode === 'globe' ? 'Globe projection · geographic context' : 'Mercator projection · geographic context'}</div>
              <div className="tt-map-legend"><span className="tt-legend-dot">Candidate</span><span className="tt-legend-dot tt-legend-selected">Selected</span></div>
              <div className="tt-map-attribution">{satelliteMode ? satelliteAttribution : mapRenderer === 'leaflet' ? '© OpenStreetMap contributors' : '© OpenFreeMap · © OpenMapTiles · © OpenStreetMap contributors'}</div>
              {!mapLoaded && !mapError && <div className="tt-map-loading" role="status" data-testid="status-map-loading">Loading real-world map tiles…</div>}
              {mapError && <div className="tt-map-error" role="alert" data-testid="status-map-error"><div><strong>Map tiles could not be loaded</strong><br />{mapError}<br /><button type="button" data-testid="button-retry-map" onClick={() => setMapKey((key) => key + 1)}><RotateCcw size={12} /> Retry map</button></div></div>}
            </div>
            <div className="tt-map-foot"><span><Crosshair size={11} /> Pins use candidate coordinates from this dataset.</span><strong>{satelliteMode ? 'Satellite backdrop is visual context; no imagery pixels enter the score.' : mapRenderer === 'leaflet' ? 'Flat geographic basemap · no elevation terrain.' : viewMode === 'globe' ? 'Globe projection · no elevation terrain.' : 'Flat projection · no elevation terrain.'}</strong></div>
            <ProfileComparison target={target} site={activeSite} />
            <MatchExplanation match={activeMatch} target={target} metric={metric} minDistanceKm={minDistanceKm} />
            <div className="tt-shortlist" data-tour="save-candidate">
              <Star size={13} color="var(--acid)" /><span>Mission shortlist</span><strong>{shortlist.length}</strong>
              {activeSite && <button type="button" data-testid="button-shortlist-selected" onClick={() => toggleShortlist(activeSite.id)}>{shortlist.includes(activeSite.id) ? 'Remove selected' : 'Save selected site'}</button>}
            </div>
            {shortlist.length > 0 && <div className="tt-shortlist-items" aria-label="Saved field-site shortlist">
              {shortlist.map((id) => {
                const site = earthSites.find((item) => item.id === id);
                if (!site) return null;
                return <div className="tt-shortlist-entry" key={id}>
                  <button type="button" data-testid={`button-open-shortlisted-${id}`} onClick={() => { setOnlyNew(false); setQuery(''); setSelectedId(id); }}>{site.name} <span>· {site.region}, {site.country}</span></button>
                  <button type="button" data-testid={`button-remove-shortlisted-${id}`} aria-label={`Remove ${site.name} from shortlist`} onClick={() => toggleShortlist(id)}>Remove</button>
                </div>;
              })}
            </div>}
          </div>

          <aside className="tt-explorer-rail">
            <div className="tt-panel-title">
              <div><div className="tt-kicker">Earth field sites</div><h2>Candidate trail</h2></div>
              <span className="tt-count">{String(matches.length).padStart(2, '0')}</span>
            </div>
            <p className="tt-ranking-caveat">Rankings compare only the illustrative profiles in this list. They are not raster-derived measurements, validated findings, or a search of all Earth.</p>
            <div className="tt-search-wrap">
              <Search size={14} /><input className="tt-search" data-testid="input-search-sites" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search sites or regions" aria-label="Search Earth field sites" />
            </div>
            {ranking.error && <div className="tt-empty" role="alert"><strong>Ranking unavailable</strong>{ranking.error}</div>}
            {!ranking.error && <div className="tt-rank-list" role="list" aria-label="Ranked Earth analog candidates">
              {matches.map((row, index) => <button key={row.site.id} type="button" role="listitem" className="tt-rank-card" data-testid={`button-select-site-${row.site.id}`} aria-pressed={row.site.id === activeSite?.id} onClick={() => { setSelectedId(row.site.id); if (map) map.flyTo({ center: [row.site.longitude, row.site.latitude], zoom: Math.max(map.getZoom(), 2.25), duration: 650 }); else leafletMap?.flyTo([row.site.latitude, row.site.longitude], Math.max(leafletMap.getZoom(), 5), { duration: 0.65 }); }}>
                <span className="tt-rank-top"><span className="tt-rank-index">{String(index + 1).padStart(2, '0')}</span><span className="tt-rank-name">{row.site.name}</span><span className="tt-rank-score">{format(row.score)}</span></span>
                <span className="tt-rank-sub"><span>{row.site.region} · {row.site.country}</span>{eligibleIds.has(row.site.id) && <span className="tt-chip">Screened</span>}</span>
                <span className="tt-meter"><span style={{ width: `${Math.max(0, Math.min(100, row.score))}%` }} /></span>
              </button>)}
              {matches.length === 0 && <div className="tt-empty"><Compass size={19} /><strong>No candidates in view</strong>Try another search, target, or novelty distance.</div>}
            </div>}
            {onlyNew && <label className="tt-weight-row">
              <span className="tt-weight-label"><span>Distance from known analogues</span><span>{minDistanceKm} km</span></span>
              <input type="range" data-testid="range-novelty-distance" min="0" max="1000" step="25" value={minDistanceKm} onChange={(event) => setMinDistanceKm(Number(event.target.value))} aria-label="Minimum distance from known analogues in kilometres" />
            </label>}
            <div className="tt-weights">
              <div className="tt-panel-title"><div className="tt-kicker"><SlidersHorizontal size={12} /> Feature weights</div><span className="tt-kicker">Adjust</span></div>
              {groups.map((group) => <label className="tt-weight-row" key={group}>
                <span className="tt-weight-label"><span>{labels[group]}</span><span>{format(weights[group])}</span></span>
                <input type="range" data-testid={`range-weight-${group}`} min="0" max="5" step=".5" value={weights[group]} onChange={(event) => setWeights((current) => ({ ...current, [group]: Number(event.target.value) }))} aria-label={`${labels[group]} weight`} />
              </label>)}
              <p className="tt-context">Zero excludes a feature group. Remaining weights are normalized before ranking.</p>
            </div>
            <section className="tt-side-card">
              <div className="tt-kicker"><Activity size={12} /> Ranking sensitivity</div>
              <h3>Challenge the ordering</h3>
              <p>Change metrics or weights to see how the candidate trail shifts. This tests the illustrative profiles, not raster resolution or map accuracy.</p>
              <div className="tt-stat-row"><span>Active metric</span><strong>{metrics[metric]}</strong></div>
              <p className="tt-metric-note">{metricNotes[metric]}</p>
              {ranking.result && <div className="tt-stat-row"><span>Top-ten median</span><strong>{format(ranking.result.medianTopTen)} / 100</strong></div>}
              <p className="tt-context"><b>Demo profiles only.</b> No NASA or Copernicus elevation rasters are loaded.</p>
            </section>
            <section className="tt-side-card tt-side-card--warning">
              <div className="tt-kicker"><CircleHelp size={12} /> Analogy limits</div>
              <h3>A candidate is not a twin.</h3>
              <p>Gravity, atmosphere, weather, grain size, chemistry, ice, and dust still differ between Earth and other worlds.</p>
              {activeSite && <div className="tt-stat-row"><span>Site caveat</span><strong>{activeSite.name}</strong></div>}
              {activeSite && <p>{activeSite.breaksDown}</p>}
              <div className="tt-stat-row"><span>Known reference sites</span><strong>{knownAnalogIds.length}</strong></div>
            </section>
          </aside>
        </section>

        <section className="tt-cases">
          <div className="tt-cases-head"><div><div className="tt-eyebrow">Mission scenarios</div><h2>Open a field rehearsal</h2></div><div className="tt-kicker">Example pairings · not scientific findings</div></div>
          <div className="tt-case-list">
            {caseStudies.map((study, index) => <button type="button" className="tt-case" data-testid={`button-case-study-${index + 1}`} key={study.id} onClick={() => openCase(study)}>
              <small>SCENARIO {String(index + 1).padStart(2, '0')}</small><strong>{study.title}</strong><span>{study.summary}</span>
            </button>)}
          </div>
        </section>

        <footer className="tt-footer">
          <span>TerraTwin · planetary field-site exploration · prototype</span>
          <button type="button" className="tt-footer-share" data-testid="button-footer-share-comparison" onClick={share}>{shareStatus || 'Share this comparison'}</button>
        </footer>
      </main>
    </div>
  </div>;
}
