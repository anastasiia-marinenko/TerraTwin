export type PlanetaryBody = 'moon' | 'mars';
export type FeatureGroup = 'slopes' | 'roughness' | 'relief' | 'curvature';
export type SimilarityMetric =
  | 'cosine'
  | 'mahalanobis'
  | 'wasserstein'
  | 'ensemble';

export type TerrainProfile = {
  /** Share of the patch in each slope bin, from 0–2° through >30°. */
  slopeHistogram: number[];
  /** Detrended roughness at two illustrative spatial scales, in metres. */
  roughness1Km: number;
  roughness5Km: number;
  /** 99th minus 1st elevation percentile, in metres. */
  reliefP99P1: number;
  /** Illustrative terrain-shape shares, from 0 to 1. */
  concavity: number;
  convexity: number;
  /** Context only; deliberately excluded from the terrain similarity score. */
  temperatureSwingC: number;
};

export type TargetSite = {
  id: string;
  body: PlanetaryBody;
  name: string;
  region: string;
  latitude: number;
  longitude: number;
  summary: string;
  profile: TerrainProfile;
};

export type EarthSite = {
  id: string;
  name: string;
  region: string;
  country: string;
  latitude: number;
  longitude: number;
  terrain: string;
  knownAnalog: boolean;
  missionUse: string;
  breaksDown: string;
  profile: TerrainProfile;
};

export type FeatureWeights = Record<FeatureGroup, number>;

const profile = (
  slopeHistogram: number[],
  roughness1Km: number,
  roughness5Km: number,
  reliefP99P1: number,
  concavity: number,
  convexity: number,
  temperatureSwingC: number,
): TerrainProfile => ({
  slopeHistogram,
  roughness1Km,
  roughness5Km,
  reliefP99P1,
  concavity,
  convexity,
  temperatureSwingC,
});

export const targets: TargetSite[] = [
  {
    id: 'moon-shackleton',
    body: 'moon',
    name: 'Shackleton Crater',
    region: "Moon's South Pole",
    latitude: -89.9,
    longitude: 0,
    summary:
      'A polar crater with rugged terrain and permanently shadowed regions near illuminated highlands.',
    profile: profile(
      [0.12, 0.16, 0.18, 0.15, 0.12, 0.1, 0.09, 0.08],
      36,
      112,
      980,
      0.28,
      0.25,
      260,
    ),
  },
  {
    id: 'moon-malapert',
    body: 'moon',
    name: 'Malapert Massif',
    region: 'Southern Lunar Highlands',
    latitude: -85.99,
    longitude: -2.3,
    summary:
      'A highland polar region that may combine long illumination periods with access to nearby craters.',
    profile: profile(
      [0.1, 0.14, 0.18, 0.17, 0.14, 0.11, 0.09, 0.07],
      32,
      104,
      820,
      0.24,
      0.28,
      220,
    ),
  },
  {
    id: 'moon-taurus-littrow',
    body: 'moon',
    name: 'Taurus–Littrow Valley',
    region: 'Mare Serenitatis, Moon',
    latitude: 20.19,
    longitude: 30.77,
    summary:
      'A volcanic valley between massifs and plains, offering a useful contrast to extreme polar regions.',
    profile: profile(
      [0.2, 0.22, 0.2, 0.15, 0.1, 0.06, 0.04, 0.03],
      18,
      62,
      540,
      0.18,
      0.2,
      180,
    ),
  },
  {
    id: 'mars-jezero',
    body: 'mars',
    name: 'Jezero Crater',
    region: 'Northern Mars',
    latitude: 18.44,
    longitude: 77.45,
    summary:
      'A crater with an ancient delta and varied terrain; a target for geology, navigation, and the search for signs of past water.',
    profile: profile(
      [0.18, 0.2, 0.19, 0.15, 0.1, 0.07, 0.06, 0.05],
      22,
      74,
      620,
      0.22,
      0.2,
      95,
    ),
  },
  {
    id: 'mars-gale',
    body: 'mars',
    name: 'Gale Crater',
    region: 'Aeolis Mons, Mars',
    latitude: -5.4,
    longitude: 137.8,
    summary:
      'A broad crater with a central mound, layered sediments, and a transition from plains to slopes.',
    profile: profile(
      [0.17, 0.19, 0.19, 0.16, 0.11, 0.07, 0.06, 0.05],
      25,
      82,
      760,
      0.23,
      0.22,
      105,
    ),
  },
];

export const earthSites: EarthSite[] = [
  {
    id: 'atacama',
    name: 'Atacama Desert',
    region: 'Antofagasta',
    country: 'Chile',
    latitude: -23.86,
    longitude: -69.13,
    terrain: 'Hyper-arid plateau, salt flats, and volcanic slopes',
    knownAnalog: true,
    missionUse: 'Field trials for robots, instruments, and navigation in a dry environment.',
    breaksDown: "Earth's atmosphere, water, and microbial life differ from the surfaces of other worlds.",
    profile: profile(
      [0.15, 0.19, 0.2, 0.16, 0.11, 0.08, 0.06, 0.05],
      29,
      91,
      710,
      0.23,
      0.2,
      36,
    ),
  },
  {
    id: 'mcmurdo-dry-valleys',
    name: 'McMurdo Dry Valleys',
    region: 'Victoria Land',
    country: 'Antarctica',
    latitude: -77.5,
    longitude: 163,
    terrain: 'Ice-free polar valleys, moraines, and exposed bedrock',
    knownAnalog: true,
    missionUse: 'Cold-weather field operations, robotic sample collection, and geological reconnaissance.',
    breaksDown: "Earth gravity, air, and the seasonal presence of meltwater remain different.",
    profile: profile(
      [0.1, 0.15, 0.2, 0.18, 0.14, 0.1, 0.07, 0.06],
      25,
      79,
      740,
      0.25,
      0.24,
      48,
    ),
  },
  {
    id: 'iceland-highlands',
    name: 'Icelandic Highlands',
    region: 'Central Iceland',
    country: 'Iceland',
    latitude: 64.8,
    longitude: -18.7,
    terrain: 'Lava fields, volcanic deserts, and glacial landforms',
    knownAnalog: true,
    missionUse: 'Comparative work on volcanic geology, mobility, and field protocols.',
    breaksDown: 'Active erosion, precipitation, a dense atmosphere, and biological processes.',
    profile: profile(
      [0.1, 0.14, 0.2, 0.18, 0.14, 0.1, 0.08, 0.06],
      37,
      112,
      880,
      0.24,
      0.26,
      34,
    ),
  },
  {
    id: 'mauna-kea',
    name: 'Mauna Kea Volcano',
    region: 'Hawaiian Islands',
    country: 'United States',
    latitude: 19.82,
    longitude: -155.47,
    terrain: 'High-elevation volcanic plateau and young lava flows',
    knownAnalog: true,
    missionUse: 'Studying volcanic materials and testing field operations on exposed terrain.',
    breaksDown: "Earth's atmosphere, precipitation, and much more active weathering.",
    profile: profile(
      [0.12, 0.16, 0.2, 0.17, 0.13, 0.09, 0.07, 0.06],
      42,
      133,
      1320,
      0.22,
      0.28,
      30,
    ),
  },
  {
    id: 'mojave',
    name: 'Mojave Desert',
    region: 'Southwestern United States',
    country: 'United States',
    latitude: 34.87,
    longitude: -116.62,
    terrain: 'Arid intermontane basin with alluvial fans',
    knownAnalog: true,
    missionUse: 'Testing mobility, sensors, field operations, and dust-handling procedures.',
    breaksDown: 'Wind and rare downpours reshape the surface; atmospheric pressure and a biosphere remain.',
    profile: profile(
      [0.22, 0.26, 0.21, 0.13, 0.08, 0.05, 0.03, 0.02],
      15,
      49,
      410,
      0.18,
      0.19,
      32,
    ),
  },
  {
    id: 'death-valley',
    name: 'Death Valley',
    region: 'California',
    country: 'United States',
    latitude: 36.24,
    longitude: -116.82,
    terrain: 'Salt basin, dunes, and steep mountain slopes',
    knownAnalog: true,
    missionUse: 'Arid-terrain field research and navigation-system trials.',
    breaksDown: "Earth's atmospheric processes and geological history are not lunar or Martian.",
    profile: profile(
      [0.17, 0.21, 0.2, 0.15, 0.1, 0.07, 0.05, 0.05],
      21,
      67,
      890,
      0.24,
      0.2,
      42,
    ),
  },
  {
    id: 'haughton',
    name: 'Haughton Crater',
    region: 'Devon Island',
    country: 'Canada',
    latitude: 75.37,
    longitude: -89.68,
    terrain: 'High-Arctic impact crater with periglacial landforms',
    knownAnalog: true,
    missionUse: 'Impact geology research and expedition-operations testing.',
    breaksDown: 'Atmospheric weathering, liquid water, and Earth gravity.',
    profile: profile(
      [0.13, 0.17, 0.2, 0.17, 0.13, 0.09, 0.06, 0.05],
      27,
      86,
      690,
      0.27,
      0.23,
      52,
    ),
  },
  {
    id: 'danakil',
    name: 'Danakil Depression',
    region: 'Afar Triangle',
    country: 'Ethiopia',
    latitude: 14.24,
    longitude: 40.3,
    terrain: 'Volcanic desert, salt plains, and geothermal fields',
    knownAnalog: false,
    missionUse: 'Comparing volcanic surfaces and testing field operations in extreme aridity.',
    breaksDown: 'Geothermal water, chemically active Earth systems, and biology.',
    profile: profile(
      [0.2, 0.23, 0.19, 0.14, 0.09, 0.06, 0.05, 0.04],
      18,
      61,
      520,
      0.2,
      0.22,
      50,
    ),
  },
  {
    id: 'makhtesh-ramon',
    name: 'Makhtesh Ramon',
    region: 'Negev',
    country: 'Israel',
    latitude: 30.6,
    longitude: 34.8,
    terrain: 'Erosion cirque with exposed rock layers and dry channels',
    knownAnalog: false,
    missionUse: 'Studying exposed strata, rover routes, and geological mapping.',
    breaksDown: 'Water and wind shape erosion in an Earth atmosphere; this is not an impact crater.',
    profile: profile(
      [0.14, 0.18, 0.21, 0.17, 0.12, 0.08, 0.06, 0.04],
      20,
      66,
      570,
      0.28,
      0.2,
      38,
    ),
  },
  {
    id: 'ladakh',
    name: 'Ladakh Plateau',
    region: 'Trans-Himalaya',
    country: 'India',
    latitude: 34.2,
    longitude: 77.6,
    terrain: 'Cold high-altitude plateau with arid valleys and sedimentary fans',
    knownAnalog: false,
    missionUse: 'Testing high-altitude operations, autonomous navigation, and geological reconnaissance.',
    breaksDown: 'Thin air is caused by elevation, not a Martian atmosphere.',
    profile: profile(
      [0.09, 0.14, 0.19, 0.18, 0.15, 0.11, 0.08, 0.06],
      34,
      109,
      1150,
      0.23,
      0.25,
      44,
    ),
  },
  {
    id: 'namib',
    name: 'Namib Plateau',
    region: 'Greater Namaqualand',
    country: 'Namibia',
    latitude: -24.9,
    longitude: 15.0,
    terrain: 'Ancient arid plateau with dunes, gravel surfaces, and exposed rock',
    knownAnalog: false,
    missionUse: 'Analyzing dust, aeolian landforms, and rover movement over loose substrate.',
    breaksDown: 'Earth winds, coastal humidity, and biological activity.',
    profile: profile(
      [0.25, 0.27, 0.18, 0.11, 0.07, 0.05, 0.04, 0.03],
      12,
      41,
      290,
      0.17,
      0.2,
      28,
    ),
  },
  {
    id: 'qaidam',
    name: 'Qaidam Basin',
    region: 'Tibetan Plateau',
    country: 'China',
    latitude: 37.0,
    longitude: 95.0,
    terrain: 'High-altitude arid basin with salt flats, dunes, and alluvial fans',
    knownAnalog: false,
    missionUse: 'Testing autonomous mobility, dust observations, and remote mapping.',
    breaksDown: 'An Earth atmosphere, water, and active weathering remain.',
    profile: profile(
      [0.2, 0.24, 0.2, 0.14, 0.09, 0.06, 0.04, 0.03],
      16,
      53,
      440,
      0.19,
      0.19,
      34,
    ),
  },
  {
    id: 'alvord',
    name: 'Alvord Desert',
    region: 'Oregon',
    country: 'United States',
    latitude: 42.5,
    longitude: -118.5,
    terrain: 'Dry lake plain between volcanic ranges',
    knownAnalog: false,
    missionUse: 'Open-plain navigation and study of interactions between salt flats and volcanic slopes.',
    breaksDown: 'Intermittent precipitation, seasonal water, and Earth atmospheric processes.',
    profile: profile(
      [0.23, 0.25, 0.2, 0.13, 0.08, 0.05, 0.03, 0.03],
      14,
      45,
      360,
      0.2,
      0.18,
      35,
    ),
  },
];

export const knownAnalogIds = earthSites
  .filter((site) => site.knownAnalog)
  .map((site) => site.id);

export const caseStudies = [
  {
    id: 'case-jezero',
    title: 'Jezero → Polar Dry Valleys',
    targetId: 'mars-jezero',
    siteId: 'mcmurdo-dry-valleys',
    summary:
      'Explore how terrain similarity might inform field protocols for exposed bedrock and cold-environment operations.',
  },
  {
    id: 'case-shackleton',
    title: 'Shackleton → Crater Landscapes',
    targetId: 'moon-shackleton',
    siteId: 'haughton',
    summary:
      'Compare basin shape and slope distribution without projecting Earth atmosphere or gravity onto the Moon.',
  },
  {
    id: 'case-gale',
    title: 'Gale → Exposed Geological Layers',
    targetId: 'mars-gale',
    siteId: 'makhtesh-ramon',
    summary:
      'Explore what dry terrestrial erosion landforms can teach about mapping routes, not crater origins.',
  },
];

export const dataSources = [
  {
    name: 'Copernicus DEM GLO-90',
    body: 'Earth',
    resolution: '90 m',
    role: 'Planned elevation source for Earth analysis windows',
    license: 'Copernicus; verify terms for the intended redistribution method',
    status: 'Not loaded in this prototype',
  },
  {
    name: 'MODIS MOD13C2 v6.1',
    body: 'Earth',
    resolution: '0.05°',
    role: 'Planned vegetation and site-eligibility filter',
    license: 'NASA EOSDIS; verify product attribution',
    status: 'Not loaded in this prototype',
  },
  {
    name: 'LOLA DEM',
    body: 'Moon',
    resolution: 'up to 256 px/degree',
    role: 'Planned lunar terrain source, including polar regions',
    license: 'NASA PDS Geosciences Node; verify product terms',
    status: 'Not loaded in this prototype',
  },
  {
    name: 'MOLA–HRSC blended DEM v2',
    body: 'Mars',
    resolution: '200 m',
    role: 'Planned Martian terrain source',
    license: 'MOLA CC0; HRSC CC BY-SA 3.0 IGO — attribution required',
    status: 'Not loaded in this prototype',
  },
];
