import {
  earthSites,
  knownAnalogIds,
  targets,
  type EarthSite,
  type FeatureGroup,
  type FeatureWeights,
  type SimilarityMetric,
  type TargetSite,
  type TerrainProfile,
} from '@/data/analogs';

const SLOPE_CENTERS_DEG = [1, 3.5, 7.5, 12.5, 17.5, 22.5, 27.5, 35];

export type FeatureScores = Record<FeatureGroup, number>;

export type RankedMatch = {
  site: EarthSite;
  score: number;
  percentile: number;
  groupScores: FeatureScores;
  contributions: FeatureScores;
  reasons: string[];
  differences: string[];
  noveltyDistanceKm: number;
  newCandidate: boolean;
};

export type RankingResult = {
  target: TargetSite;
  metric: SimilarityMetric;
  weights: FeatureWeights;
  results: RankedMatch[];
  topGap: number;
  medianTopTen: number;
  methodNote: string;
};

const median = (values: number[]) => {
  const sorted = [...values].sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2
    ? sorted[middle]
    : (sorted[middle - 1] + sorted[middle]) / 2;
};

const normalizedSlopeHistogram = (profile: TerrainProfile) => {
  const total = profile.slopeHistogram.reduce((sum, value) => sum + value, 0);
  return total > 0
    ? profile.slopeHistogram.map((value) => value / total)
    : profile.slopeHistogram.map(() => 0);
};

const featureGroups: Record<FeatureGroup, (profile: TerrainProfile) => number[]> = {
  slopes: normalizedSlopeHistogram,
  roughness: (p) => [p.roughness1Km, p.roughness5Km],
  relief: (p) => [p.reliefP99P1],
  curvature: (p) => [p.concavity, p.convexity],
};

function robustScales(group: FeatureGroup) {
  if (group === 'slopes') return [];
  const vectors = earthSites.map((site) => featureGroups[group](site.profile));
  const width = vectors[0].length;
  return Array.from({ length: width }, (_, index) => {
    const values = vectors.map((row) => row[index]);
    const center = median(values);
    const mad = median(values.map((value) => Math.abs(value - center)));
    return Math.max(mad * 1.4826, (Math.max(...values) - Math.min(...values)) / 6, 0.05);
  });
}

function cosineSimilarity(a: number[], b: number[]) {
  const dot = a.reduce((sum, value, index) => sum + value * b[index], 0);
  const normA = Math.sqrt(a.reduce((sum, value) => sum + value * value, 0));
  const normB = Math.sqrt(b.reduce((sum, value) => sum + value * value, 0));
  if (normA < 1e-9 && normB < 1e-9) return 1;
  if (normA < 1e-9 || normB < 1e-9) return 0.5;
  return Math.max(0, Math.min(1, (dot / (normA * normB) + 1) / 2));
}

function wasserstein1(a: number[], b: number[]) {
  let cumulativeDifference = 0;
  let distance = 0;
  for (let index = 0; index < Math.min(a.length, b.length); index += 1) {
    cumulativeDifference += a[index] - b[index];
    const width =
      SLOPE_CENTERS_DEG[index + 1] !== undefined
        ? SLOPE_CENTERS_DEG[index + 1] - SLOPE_CENTERS_DEG[index]
        : 0;
    distance += Math.abs(cumulativeDifference) * width;
  }
  return distance / SLOPE_CENTERS_DEG.at(-1)!;
}

function groupDistance(
  group: FeatureGroup,
  target: TerrainProfile,
  site: TerrainProfile,
  metric: SimilarityMetric,
) {
  const targetValues = featureGroups[group](target);
  const siteValues = featureGroups[group](site);

  if (metric === 'cosine') {
    return 1 - cosineSimilarity(targetValues, siteValues);
  }

  if (metric === 'wasserstein') {
    if (group === 'slopes') return wasserstein1(targetValues, siteValues);
    const scales = robustScales(group);
    const sortedTarget = targetValues
      .map((value, index) => value / scales[index])
      .sort((a, b) => a - b);
    const sortedSite = siteValues
      .map((value, index) => value / scales[index])
      .sort((a, b) => a - b);
    return (
      sortedTarget.reduce(
        (sum, value, index) => sum + Math.abs(value - sortedSite[index]),
        0,
      ) / Math.max(1, sortedTarget.length)
    );
  }

  if (group === 'slopes') {
    return Math.sqrt(
      targetValues.reduce((sum, value, index) => sum + (value - siteValues[index]) ** 2, 0),
    );
  }
  const scales = robustScales(group);
  const squaredDistance = targetValues.reduce((sum, value, index) => {
    const standardizedDifference = (value - siteValues[index]) / scales[index];
    return sum + standardizedDifference ** 2;
  }, 0);
  return Math.sqrt(squaredDistance / Math.max(1, targetValues.length));
}

function metricSimilarity(group: FeatureGroup, distance: number, metric: SimilarityMetric) {
  if (metric === 'cosine') return 1 - distance;
  const decay = group === 'slopes' ? 2.5 : 0.82;
  return Math.exp(-distance * decay);
}

function groupSimilarity(
  group: FeatureGroup,
  target: TerrainProfile,
  site: TerrainProfile,
  metric: SimilarityMetric,
) {
  if (metric === 'ensemble') {
    return (['cosine', 'mahalanobis', 'wasserstein'] as const).reduce(
      (sum, method) =>
        sum +
        metricSimilarity(group, groupDistance(group, target, site, method), method) / 3,
      0,
    );
  }
  return metricSimilarity(
    group,
    groupDistance(group, target, site, metric),
    metric,
  );
}

export function haversineKm(
  latitudeA: number,
  longitudeA: number,
  latitudeB: number,
  longitudeB: number,
) {
  const radians = (degrees: number) => (degrees * Math.PI) / 180;
  const dLat = radians(latitudeB - latitudeA);
  const dLon = radians(longitudeB - longitudeA);
  const latA = radians(latitudeA);
  const latB = radians(latitudeB);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(latA) * Math.cos(latB) * Math.sin(dLon / 2) ** 2;
  return 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function nearestKnownAnalog(site: EarthSite) {
  return earthSites
    .filter((candidate) => candidate.knownAnalog)
    .reduce(
      (nearest, candidate) =>
        Math.min(
          nearest,
          haversineKm(
            site.latitude,
            site.longitude,
            candidate.latitude,
            candidate.longitude,
          ),
        ),
      Number.POSITIVE_INFINITY,
    );
}

export function isNewCandidate(
  site: EarthSite,
  knownIds: string[] = knownAnalogIds,
  minDistanceKm = 200,
) {
  return !knownIds.includes(site.id) && nearestKnownAnalog(site) >= minDistanceKm;
}

const groupLabels: Record<FeatureGroup, string> = {
  slopes: 'Slope distribution',
  roughness: 'Multi-scale roughness',
  relief: 'Elevation range',
  curvature: 'Concave and convex forms',
};

export function getRankedMatches(
  targetId: string,
  metric: SimilarityMetric,
  weights: FeatureWeights,
  _windowKm = 20,
  _scaleM = 200,
): RankingResult {
  const target = targets.find((item) => item.id === targetId);
  if (!target) throw new Error(`Unknown planetary target: ${targetId}`);

  const groupNames = Object.keys(featureGroups) as FeatureGroup[];
  const totalWeight = groupNames.reduce(
    (sum, group) => sum + Math.max(0, weights[group]),
    0,
  );
  if (totalWeight === 0) {
    throw new Error('Set a positive weight for at least one feature group.');
  }
  const normalizedWeights = Object.fromEntries(
    groupNames.map((group) => [
      group,
      Math.max(0, weights[group]) / totalWeight,
    ]),
  ) as FeatureWeights;

  const ranked = earthSites.map((site) => {
    const groupScores = Object.fromEntries(
      groupNames.map((group) => [
        group,
        groupSimilarity(group, target.profile, site.profile, metric),
      ]),
    ) as FeatureScores;
    const contributions = Object.fromEntries(
      groupNames.map((group) => [
        group,
        groupScores[group] * normalizedWeights[group],
      ]),
    ) as FeatureScores;
    const score = groupNames.reduce(
      (sum, group) => sum + contributions[group],
      0,
    );
    const sortedGroups = [...groupNames].sort(
      (a, b) => groupScores[b] - groupScores[a],
    );
    const weakGroups = [...groupNames].sort(
      (a, b) => groupScores[a] - groupScores[b],
    );
    const noveltyDistanceKm = nearestKnownAnalog(site);
    return {
      site,
      score: score * 100,
      percentile: 0,
      groupScores,
      contributions,
      reasons: sortedGroups.slice(0, 3).map((group) => groupLabels[group]),
      differences: weakGroups
        .filter((group) => groupScores[group] < 0.86)
        .slice(0, 3)
        .map((group) => groupLabels[group]),
      noveltyDistanceKm,
      newCandidate: isNewCandidate(site),
    };
  });

  ranked.sort((a, b) => b.score - a.score);
  const denominator = Math.max(1, ranked.length - 1);
  ranked.forEach((match, index) => {
    match.percentile = ((ranked.length - index - 1) / denominator) * 100;
  });
  const topTen = ranked.slice(0, 10).map((match) => match.score);
  const medianTopTen = median(topTen);

  return {
    target,
    metric,
    weights: normalizedWeights,
    results: ranked,
    topGap: Math.max(0, ranked[0].score - medianTopTen),
    medianTopTen,
    methodNote:
      metric === 'mahalanobis'
        ? 'Diagonal Mahalanobis approximation with robust feature scaling; full covariance is not estimated.'
        : metric === 'wasserstein'
          ? 'Wasserstein distance compares slope histograms and feature distributions.'
          : metric === 'ensemble'
            ? 'Mean of three metrics: cosine similarity, diagonal Mahalanobis approximation, and Wasserstein distance.'
            : 'Cosine similarity is computed separately within each feature group.',
  };
}

export function getDualRankedMatches(
  moonTargetId: string,
  marsTargetId: string,
  metric: SimilarityMetric,
  weights: FeatureWeights,
) {
  const moon = getRankedMatches(moonTargetId, metric, weights);
  const mars = getRankedMatches(marsTargetId, metric, weights);
  const byId = new Map<string, { moon: RankedMatch; mars: RankedMatch }>();
  moon.results.forEach((match) => {
    const marsMatch = mars.results.find((candidate) => candidate.site.id === match.site.id);
    if (marsMatch) byId.set(match.site.id, { moon: match, mars: marsMatch });
  });
  return [...byId.entries()]
    .map(([id, pair]) => ({
      site: pair.moon.site,
      score: (pair.moon.score + pair.mars.score) / 2,
      moonScore: pair.moon.score,
      marsScore: pair.mars.score,
      newCandidate: pair.moon.newCandidate,
      noveltyDistanceKm: pair.moon.noveltyDistanceKm,
      percentile: 0,
      groupScores: Object.fromEntries(
        (Object.keys(pair.moon.groupScores) as FeatureGroup[]).map((group) => [
          group,
          (pair.moon.groupScores[group] + pair.mars.groupScores[group]) / 2,
        ]),
      ) as FeatureScores,
      contributions: pair.moon.contributions,
      reasons: pair.moon.reasons.filter((reason) => pair.mars.reasons.includes(reason)),
      differences: [
        ...new Set([...pair.moon.differences, ...pair.mars.differences]),
      ].slice(0, 3),
      id,
    }))
    .sort((a, b) => b.score - a.score)
    .map((match, index, all) => ({
      ...match,
      percentile: ((all.length - index - 1) / Math.max(1, all.length - 1)) * 100,
    }));
}

export function getTargetById(targetId: string) {
  return targets.find((target) => target.id === targetId);
}

export function getSiteById(siteId: string) {
  return earthSites.find((site) => site.id === siteId);
}
