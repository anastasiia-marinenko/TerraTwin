import { AlertTriangle, ArrowRight, CheckCircle2, Database, Layers3, Map, Ruler } from 'lucide-react';
import { Link } from 'wouter';
import { dataSources } from '@/data/analogs';

const featureGroups = [
  { name: 'Slope distribution', detail: 'Illustrative shares across slope-angle bins; the prototype normalizes the histogram before comparison.' },
  { name: 'Surface roughness', detail: 'Two illustrative spatial scales are compared as a compact feature vector.' },
  { name: 'Elevation relief', detail: 'An illustrative percentile range represents local relief in the demo profiles.' },
  { name: 'Terrain shape', detail: 'Concavity and convexity shares form the final illustrative feature group.' },
];

const researchResources = [
  {
    name: 'NASA Earthdata Search',
    url: 'https://search.earthdata.nasa.gov/',
    relevance: 'Searches NASA Earth-observation datasets and supports discovery of Earth products that could inform future site characterization.',
  },
  {
    name: 'NASA Worldview',
    url: 'https://worldview.earthdata.nasa.gov/',
    relevance: 'Provides interactive access to satellite imagery and geospatial layers for visual review of Earth conditions and events.',
  },
  {
    name: 'NASA Planetary Data System',
    url: 'https://pds.nasa.gov/',
    relevance: 'Archives NASA planetary mission data and documentation that can support traceable lunar and Martian terrain research.',
  },
  {
    name: 'NASA LRO data archive',
    url: 'https://pds-geosciences.wustl.edu/missions/lro/',
    relevance: 'The PDS Geosciences Node hosts Lunar Reconnaissance Orbiter geoscience datasets that are relevant to lunar surface studies.',
  },
  {
    name: 'LRO Diviner',
    url: 'https://pds-geosciences.wustl.edu/missions/lro/diviner.htm',
    relevance: 'Diviner measures lunar surface thermal emission and temperature, providing environmental context rather than terrain scores in this prototype.',
  },
  {
    name: 'CSA RADARSAT Constellation Mission',
    url: 'https://donnees-data.asc-csa.gc.ca/en/dataset/rcm',
    relevance: 'The Canadian Space Agency catalog describes RCM synthetic-aperture radar data that can support future Earth surface and site studies.',
  },
  {
    name: 'RADARSAT-1',
    url: 'https://donnees-data.asc-csa.gc.ca/en/dataset/radarsat1',
    relevance: 'This catalog provides access information for historical RADARSAT-1 radar observations that may help characterize Earth field settings.',
  },
  {
    name: 'CSA Synthetic Aperture Radar tutorial',
    url: 'https://github.com/asc-csa/Synthetic_Aperture_Radar_Tutorial',
    relevance: 'The tutorial introduces SAR concepts and processing workflows for interpreting radar imagery; it is educational material, not a dataset loaded here.',
  },
  {
    name: 'Copernicus Data Space Ecosystem',
    url: 'https://dataspace.copernicus.eu/',
    relevance: 'Provides access to Copernicus Earth-observation products that could support future Earth-site context and analysis.',
  },
  {
    name: 'ESA Open Science Catalog',
    url: 'https://opensciencedata.esa.int/',
    relevance: 'Catalogs open ESA science datasets, including mission resources that may support planetary and Earth-observation research.',
  },
  {
    name: 'JAXA G-Portal',
    url: 'https://gportal.jaxa.jp/gpr/index/index',
    relevance: 'JAXA’s portal provides Earth-observation data access and documentation relevant to future Earth-site characterization.',
  },
  {
    name: 'NASA Image and Video Library',
    url: 'https://images.nasa.gov/',
    relevance: 'The public NASA media library supplies credited regional images when no nearby geotagged field photograph is available.',
  },
];

export default function MethodPage() {
  return (
    <main className="story-page">
      <section className="page-heading">
        <div className="page-heading-index">CHAPTER 05 / METHOD & LIMITS</div>
        <p className="story-eyebrow">A transparent prototype, not a scientific result</p>
        <h1>Keep the analogy.<br /><em>Interrogate the evidence.</em></h1>
        <p className="page-lede">The current instrument is a local comparison of illustrative profiles over a geographic basemap. No rasters are ingested and no candidate score is a measured NASA finding.</p>
      </section>
      <section className="method-banner">
        <div className="method-banner-icon"><AlertTriangle size={18} /></div>
        <div><strong>All visible terrain values are illustrative.</strong><p>Ranks, percentiles, feature bars, and novelty labels are computed from the existing demo records. They are not measurements, discoveries, or validated results.</p></div>
      </section>
      <section className="method-content-grid">
        <div className="method-section">
          <div className="method-section-kicker"><Layers3 size={14} /> FEATURE GROUPS</div>
          <h2>Four views of terrain form.</h2>
          <p className="method-prose">Each group can be given a different weight in the explorer. Weights are normalized across active groups. Temperature context is deliberately excluded from the similarity score.</p>
          <div className="feature-list">{featureGroups.map((feature, index) => <article key={feature.name}><span>{String(index + 1).padStart(2, '0')}</span><div><strong>{feature.name}</strong><p>{feature.detail}</p></div></article>)}</div>
        </div>
        <div className="method-section metric-section">
          <div className="method-section-kicker"><Ruler size={14} /> LOCAL COMPARISON</div>
          <h2>Scores describe this list.</h2>
          <p className="method-prose">Available metrics are cosine similarity, a robustly scaled diagonal Mahalanobis approximation, Wasserstein distance, and an ensemble that averages the three. The diagonal approximation does not estimate full covariance.</p>
          <div className="method-equation"><span>PROFILE → FEATURE GROUPS → WEIGHTED METRIC</span><b>≠</b><span>FIELD VALIDATION</span></div>
          <p className="method-prose">Candidate ranking is relative to the existing Earth-site records. A novelty filter applies a distance rule from known reference-site coordinates; it is not a novelty discovery or a completeness claim about Earth.</p>
        </div>
      </section>
      <section className="method-limits" data-tour="method-limits">
        <div><div className="method-section-kicker"><Map size={14} /> MAP & ANALOGY LIMITS</div><h2>A map is not a terrain model.</h2></div>
        <div className="limit-points">
          <p><CheckCircle2 size={15} />The interactive globe is a geographic projection of the Earth basemap, not 3D elevation terrain.</p>
          <p><CheckCircle2 size={15} />Map pins show candidate coordinates from the existing local dataset; they are not raster analysis windows.</p>
          <p><CheckCircle2 size={15} />Earth gravity, atmosphere, weather, biology, chemistry, materials, and geological history differ from lunar and Martian environments.</p>
          <p><CheckCircle2 size={15} />An analogue may support operational rehearsal without being physically or geologically equivalent to a target.</p>
        </div>
      </section>
      <section className="sources-section">
        <div className="sources-heading"><div><div className="method-section-kicker"><Database size={14} /> SOURCE STATUS</div><h2>Planned sources, not loaded sources.</h2></div><span>NO RASTER INGESTION</span></div>
        <div className="sources-grid">{dataSources.map((source) => <article className="source-row" key={source.name}><div><strong>{source.name}</strong><span>{source.body} · {source.resolution}</span></div><p>{source.role}</p><small>{source.status}. {source.license}.</small></article>)}</div>
        <div className="resource-heading"><h3>Research portals and data catalogs</h3><p>These links identify potential research resources; this prototype has not downloaded, ingested, or analyzed data from them.</p></div>
        <div className="sources-grid research-resources">
          {researchResources.map((resource) => <article className="source-row research-resource" key={resource.url}>
            <div><strong>{resource.name}</strong><a href={resource.url} target="_blank" rel="noreferrer">{resource.url}<span aria-hidden="true"> ↗</span></a></div>
            <p>{resource.relevance}</p>
            <small>External resource · not currently ingested by TerraTwin.</small>
          </article>)}
        </div>
      </section>
      <section className="validation-intent">
        <span className="story-eyebrow">Validation intention</span>
        <h2>Future work should test whether the method behaves responsibly.</h2>
        <p>Before any real-data interpretation, candidate comparisons would need documented data lineage, scale and resolution sensitivity checks, and evaluation against known analog sites. That validation has not been performed in this prototype.</p>
        <Link href="/explorer" className="story-text-link" data-testid="link-method-explorer">Return to the candidate trail <ArrowRight size={14} /></Link>
      </section>
    </main>
  );
}
